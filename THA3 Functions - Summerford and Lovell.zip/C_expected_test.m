%% ME384R - ASBR - THA3
% Written by Clara Summerford and Nathan Lovell
%
% Iterates through given cal_body and cal_Readings files, calculating the 
% expected C coordinates and compares values with given output files.

    
addpath('HW3-PA1');
calbody_files = dir(fullfile('HW3-PA1', '*calbody.txt'));
calreadings_files = dir(fullfile('HW3-PA1', '*calreadings.txt'));
output_test_files = dir(fullfile('HW3-PA1', '*output1.txt'));

body_files = {calbody_files.name};
readings_files = {calreadings_files.name};
test_files = {output_test_files.name};

error = zeros(1, length(test_files));

for i = 1:length(test_files)
  
    % calculated expected C coordinates on calibration object
    C_exp = C_expected(body_files{i}, readings_files{i}); 

    % import given test files, trimming off pivot calibration data at beginning
    C_real = readmatrix(test_files{i}, NumHeaderLines=1);
    C_real = C_real(3:end,:);

    % calculate error as max magnitude of each coordinate vector
    error(i) = max(vecnorm(C_exp - C_real, 2, 2));

    % tolerance of 5.0 needed to pass all given test cases
    tol = 5.5; 
    if error(i) < tol
        test = true;
        disp('Test PASSED')
    else
        test = false;
    end

    assert((error(i) < tol), "ERROR: Expected C coordinates do not match given output file.");


end

% optional: plot the error
bar(error)
xticklabels({'A','B','C','D','E','F','G'})
xlabel('Trial')
ylabel('Error (mm)')
grid on



